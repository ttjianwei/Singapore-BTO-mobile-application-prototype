package com.gjenterprise.canxer.btosg.Entity;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import java.util.ArrayList;
import java.util.List;

/**
 * Created by HaoZhe on 20/10/2016.
 */

public class DbHandler extends SQLiteOpenHelper {
    private SQLiteDatabase myDataBase;

    // Database Version
    private static final int DATABASE_VERSION = 1;
    /**
     *  Represents the path of the database.
     */
    public String DATABASE_PATH = "";
    // Database Name
    private static final String DATABASE_NAME = "ViewFlats";
    // Flats table name
    private static final String TABLE_FlatCollection = "FlatCollection";
    // Flats Table Columns names
    private static final String KEY_ID = "id";
    private static final String KEY_FINANCIAL_YEAR = "financial_year";
    private static final String KEY_TOWN = "town";
    private static final String KEY_ROOM_TYPE = "room_type";
    private static final String KEY_MIN_SELLING_PRICE = "min_selling_price";
    private static final String KEY_MAX_SELLING_PRICE = "max_selling_price";
    private static final String KEY_MIN_SELLING_PRICE_AHG = "min_selling_price_ahg";
    private static final String KEY_MAX_SELLING_PRICE_AHG = "max_selling_price_ahg";

    public DbHandler(Context context) {
        super(context, DATABASE_NAME, null, DATABASE_VERSION);
        DATABASE_PATH = context.getDatabasePath("ViewFlats.db").getPath();
    }
     @Override
     public void onCreate(SQLiteDatabase db) {
         String CREATE_FLATS_TABLE = "CREATE TABLE " + TABLE_FlatCollection + "("
         + KEY_ID + " INTEGER PRIMARY KEY,"
         + KEY_FINANCIAL_YEAR + " INT,"
         + KEY_TOWN  + " TEXT,"
         + KEY_ROOM_TYPE + " TEXT " + ")"
         + KEY_MIN_SELLING_PRICE + " INT " + ")"
         + KEY_MAX_SELLING_PRICE + " INT " + ")"
         + KEY_MIN_SELLING_PRICE_AHG + " TEXT " + ")"
         + KEY_MAX_SELLING_PRICE_AHG + " TEXT " + ")";
         db.execSQL(CREATE_FLATS_TABLE);
     }
    public SQLiteDatabase openDatabase()
    {
        String myPath = DATABASE_PATH;
        myDataBase = SQLiteDatabase.openDatabase(myPath, null, SQLiteDatabase.OPEN_READWRITE);
        return myDataBase;
    }
    public synchronized void closeDataBase()
    {
        if(myDataBase != null)
            myDataBase.close();
        super.close();
    }
    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
    // Drop older table if existed
        db.execSQL("DROP TABLE IF EXISTS " + TABLE_FlatCollection);
    // Creating tables again
        onCreate(db);
    }
    // Adding new flats
    public void addFlats(FlatDetails flats) {
        SQLiteDatabase db = this.getWritableDatabase();

        ContentValues values = new ContentValues();
        values.put(KEY_ID, flats.getId());
        values.put(KEY_FINANCIAL_YEAR, flats.getFinancial_year()); // financial year
        values.put(KEY_TOWN, flats.getTown()); // town
        values.put(KEY_ROOM_TYPE, flats.getRoom_type()); // room type
        values.put(KEY_MIN_SELLING_PRICE, flats.getMin_selling_price()); // min selling price
        values.put(KEY_MAX_SELLING_PRICE, flats.getMax_selling_price()); // max selling price
        values.put(KEY_MIN_SELLING_PRICE_AHG, flats.getMin_selling_price_ahg()); // min selling price_ahg
        values.put(KEY_MAX_SELLING_PRICE_AHG, flats.getMax_selling_price_ahg()); // max selling price_ahg

    // Inserting Row
        db.insert(TABLE_FlatCollection, null, values);
        db.close(); // Closing database connection
    }

    // Getting All Flats
    public List<FlatDetails> getAllFlats() {
        List<FlatDetails> flatsList = new ArrayList<FlatDetails>();
    // Select All Query
        String selectQuery = "SELECT * FROM " + TABLE_FlatCollection;
        SQLiteDatabase db = this.getWritableDatabase();
        Cursor cursor = db.rawQuery(selectQuery, null);

    // looping through all rows and adding to list
        if (cursor.moveToFirst()) {
            do {
                FlatDetails flats = new FlatDetails();
                flats.setId(Integer.parseInt(cursor.getString(0)));
                flats.setFinancial_year(Integer.parseInt(cursor.getString(1)));
                flats.setTown(cursor.getString(2));
                flats.setRoom_type(cursor.getString(3));
                flats.setMin_selling_price(Integer.parseInt(cursor.getString(4)));
                flats.setMax_selling_price(Integer.parseInt(cursor.getString(5)));
                flats.setMin_selling_price_ahg(cursor.getString(6));
                flats.setMax_selling_price_ahg(cursor.getString(7));

    // Adding flats to list
             flatsList.add(flats);
            } while (cursor.moveToNext());
        }
    // return contact list
        return flatsList;

    }
}
