package com.gjenterprise.canxer.btosg.Boundary;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.Toolbar;
import android.text.method.LinkMovementMethod;
import android.view.Menu;
import android.view.View;
import android.content.Intent;
import android.widget.TextView;
import android.text.Html;

import com.gjenterprise.canxer.btosg.Control.MainMenu;
import com.gjenterprise.canxer.btosg.R;

/**
 * Created by Canxer on 8/10/2016.
 */
public class GrantResultUI extends AppCompatActivity {
    MainMenu mainMenu;
    private String grant="Nil";

    public boolean onCreateOptionsMenu(Menu menu) {

        getMenuInflater().inflate(R.menu.menu, menu);
        return super.onCreateOptionsMenu(menu);
    }
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_grantresult);
        Toolbar my_toolbar = (Toolbar) findViewById(R.id.my_toolbar);
        setSupportActionBar(my_toolbar);
        getSupportActionBar().setTitle(R.string.my_tb_title);
        getSupportActionBar().setSubtitle("Grant Result");

        TextView textView=(TextView)findViewById(R.id.textViewResult);
        TextView tv2=(TextView)findViewById(R.id.textDescript);

        tv2.setClickable(true);
        tv2.setMovementMethod(LinkMovementMethod.getInstance());

        String form1="<a href='https://www20.hdb.gov.sg/isoa072p.nsf/PC66FHDBFormsForWeb?OpenForm&Header=Residential&SubCat=BuyingaNewFlat&MainCategory=Buying%20a%20New%20Flat'> Housing Grant Form </a>";
        tv2.setText(Html.fromHtml(form1));

        grant=getIntent().getStringExtra("grantAmt");

        if(grant.equals("Nil"))
            grant="Sorry! You are not eligible for any grant!";
        else
            grant="Congratulations! You will receive "+ grant;

        textView.setText(grant);
    }

    public void viewGrant(View view) {
        // Do something in response to button
        Intent intent = new Intent(this,GrantQueryUI.class);
        intent.putExtra("mainMenu", mainMenu);
        startActivity(intent);
    }
    public void viewRepayment(View view) {
        // Do something in response to button
        Intent intent = new Intent(this,RepaymentQueryUI.class);
        intent.putExtra("mainMenu", mainMenu);
        startActivity(intent);
    }
    public void viewFlats(View view) {
        // Do something in response to button
        Intent intent = new Intent(this,ViewFlatQueryUI.class);
        intent.putExtra("mainMenu", mainMenu);
        startActivity(intent);
    }
}
