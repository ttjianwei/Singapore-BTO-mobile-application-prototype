package com.gjenterprise.canxer.btosg.Boundary;

import android.content.Intent;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.Toolbar;
import android.view.Menu;
import android.view.MenuItem;

import com.gjenterprise.canxer.btosg.Control.MainMenu;
import com.gjenterprise.canxer.btosg.R;

/**
 * Created by HaoZhe on 13/11/2016.
 */

public class MenuContactUs extends AppCompatActivity {
    MainMenu mainMenu;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_contactus);
        Toolbar my_toolbar = (Toolbar) findViewById(R.id.my_toolbar);
        setSupportActionBar(my_toolbar);

        getSupportActionBar().setTitle(R.string.my_tb_title);
        getSupportActionBar().setSubtitle("Contact Us");

    }
    public boolean onCreateOptionsMenu(Menu menu) {

        getMenuInflater().inflate(R.menu.menu, menu);
        return super.onCreateOptionsMenu(menu);
    }
    @Override
    public boolean onOptionsItemSelected(MenuItem item){
        int id = item.getItemId();
        if (id == R.id.Home) {
            Intent intent = new Intent(this,MainMenuUI.class);
            this.startActivity(intent);
            return true;
        }

        if (id == R.id.about) {
            Intent intent = new Intent(this,MenuAboutUs.class);
            this.startActivity(intent);
            return true;
        }
        if (id == R.id.contact) {
            Intent intent = new Intent(this,MenuContactUs.class);
            this.startActivity(intent);
            return true;

        }
        return super.onOptionsItemSelected(item);

    }
}
