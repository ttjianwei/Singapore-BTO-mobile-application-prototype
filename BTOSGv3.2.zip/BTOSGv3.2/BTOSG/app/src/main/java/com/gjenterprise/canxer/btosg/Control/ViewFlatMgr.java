package com.gjenterprise.canxer.btosg.Control;

import android.content.Context;
import android.content.Intent;
import android.widget.ListView;
import android.app.Activity;


import com.gjenterprise.canxer.btosg.Boundary.ViewFlatQueryUI;

import com.gjenterprise.canxer.btosg.R;


/**
 * Created by Canxer on 8/10/2016.
 */
public class ViewFlatMgr extends Activity {

    Context context;
    MainMenu mainMenu;

    private ListView lv;

    String[] test;
    public void GetFlatDetails(String location, String price, String room) {
        String textLocation = "Nil";
        String textPriceRange= "Nil";
        String textRoom= "Nil";

        textLocation = getIntent().getStringExtra("textLocation");
        textPriceRange = getIntent().getStringExtra("textPriceRange");
        textRoom = getIntent().getStringExtra("textRoom");

        if(textLocation.equals("Bukit Panjang")) {
            if(textPriceRange.equals("50,001 - 200,000")) {
                if(textRoom.equals("1 Room"))
                {
                    test = getResources().getStringArray(R.array.bp1room50);
                }
                else if (textRoom.equals("2 Room"))
                {
                    test = getResources().getStringArray(R.array.bp2room50);
                }
                else if (textRoom.equals("3 Room"))
                {
                    test = getResources().getStringArray(R.array.nodata);
                }
                else if (textRoom.equals("4 Room"))
                {
                    test = getResources().getStringArray(R.array.nodata);
                }
                else if (textRoom.equals("5 Room"))
                {
                    test = getResources().getStringArray(R.array.nodata);
                }
            }
            if(textPriceRange.equals("200,001 - 350,000")) {
                if(textRoom.equals("1 Room"))
                {
                    test = getResources().getStringArray(R.array.nodata);
                }
                else if (textRoom.equals("2 Room"))
                {
                    test = getResources().getStringArray(R.array.bp2room200);
                }
                else if (textRoom.equals("3 Room"))
                {
                    test = getResources().getStringArray(R.array.bp3room200);
                }
                else if (textRoom.equals("4 Room"))
                {
                    test = getResources().getStringArray(R.array.nodata);
                }
                else if (textRoom.equals("5 Room"))
                {
                    test = getResources().getStringArray(R.array.nodata);
                }
            }
            if(textPriceRange.equals("350,001 - 500,000")) {
                if(textRoom.equals("1 Room"))
                {
                    test = getResources().getStringArray(R.array.nodata);
                }
                else if (textRoom.equals("2 Room"))
                {
                    test = getResources().getStringArray(R.array.nodata);
                }
                else if (textRoom.equals("3 Room"))
                {
                    test = getResources().getStringArray(R.array.bp3room350);
                }
                else if (textRoom.equals("4 Room"))
                {
                    test = getResources().getStringArray(R.array.bp4room350);
                }
                else if (textRoom.equals("5 Room"))
                {
                    test = getResources().getStringArray(R.array.nodata);
                }
            }
            if(textPriceRange.equals("500,001 - 750,000")) {
                if(textRoom.equals("1 Room"))
                {
                    test = getResources().getStringArray(R.array.nodata);
                }
                else if (textRoom.equals("2 Room"))
                {
                    test = getResources().getStringArray(R.array.nodata);
                }
                else if (textRoom.equals("3 Room"))
                {
                    test = getResources().getStringArray(R.array.nodata);
                }
                else if (textRoom.equals("4 Room"))
                {
                    test = getResources().getStringArray(R.array.bp4room500);
                }
                else if (textRoom.equals("5 Room"))
                {
                    test = getResources().getStringArray(R.array.bp5room500);
                }
            }

        }
        else if(textLocation.equals("Choa Chu Kang")) {
            if(textPriceRange.equals("50,001 - 200,000")) {
                if(textRoom.equals("1 Room"))
                {
                    test = getResources().getStringArray(R.array.cck1room50);
                }
                else if (textRoom.equals("2 Room"))
                {
                    test = getResources().getStringArray(R.array.cck2room50);
                }
                else if (textRoom.equals("3 Room"))
                {
                    test = getResources().getStringArray(R.array.nodata);
                }
                else if (textRoom.equals("4 Room"))
                {
                    test = getResources().getStringArray(R.array.nodata);
                }
                else if (textRoom.equals("5 Room"))
                {
                    test = getResources().getStringArray(R.array.nodata);
                }
            }
            if(textPriceRange.equals("200,001 - 350,000")) {
                if(textRoom.equals("1 Room"))
                {
                    test = getResources().getStringArray(R.array.nodata);
                }
                else if (textRoom.equals("2 Room"))
                {
                    test = getResources().getStringArray(R.array.cck2room200);
                }
                else if (textRoom.equals("3 Room"))
                {
                    test = getResources().getStringArray(R.array.cck3room200);
                }
                else if (textRoom.equals("4 Room"))
                {
                    test = getResources().getStringArray(R.array.nodata);
                }
                else if (textRoom.equals("5 Room"))
                {
                    test = getResources().getStringArray(R.array.nodata);
                }
            }
            if(textPriceRange.equals("350,001 - 500,000")) {
                if(textRoom.equals("1 Room"))
                {
                    test = getResources().getStringArray(R.array.nodata);
                }
                else if (textRoom.equals("2 Room"))
                {
                    test = getResources().getStringArray(R.array.nodata);
                }
                else if (textRoom.equals("3 Room"))
                {
                    test = getResources().getStringArray(R.array.cck3room350);
                }
                else if (textRoom.equals("4 Room"))
                {
                    test = getResources().getStringArray(R.array.cck4room350);
                }
                else if (textRoom.equals("5 Room"))
                {
                    test = getResources().getStringArray(R.array.nodata);
                }
            }
            if(textPriceRange.equals("500,001 - 750,000")) {
                if(textRoom.equals("1 Room"))
                {
                    test = getResources().getStringArray(R.array.nodata);
                }
                else if (textRoom.equals("2 Room"))
                {
                    test = getResources().getStringArray(R.array.nodata);
                }
                else if (textRoom.equals("3 Room"))
                {
                    test = getResources().getStringArray(R.array.nodata);
                }
                else if (textRoom.equals("4 Room"))
                {
                    test = getResources().getStringArray(R.array.cck4room500);
                }
                else if (textRoom.equals("5 Room"))
                {
                    test = getResources().getStringArray(R.array.cck4room500);
                }
            }

        }
        else{
            test = getResources().getStringArray(R.array.nodata);
        }
        Intent intent = new Intent(ViewFlatMgr.this,ViewFlatQueryUI.class);
        intent.putExtra("results",test);
        context.startActivity(intent);
    }
}

