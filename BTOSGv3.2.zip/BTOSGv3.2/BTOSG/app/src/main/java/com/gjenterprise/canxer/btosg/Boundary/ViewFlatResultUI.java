package com.gjenterprise.canxer.btosg.Boundary;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.content.Intent;

import com.gjenterprise.canxer.btosg.R;

import android.support.v7.widget.Toolbar;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.ListView;
import android.widget.TextView;

import com.gjenterprise.canxer.btosg.Control.MainMenu;

import java.util.ArrayList;

/**
 * Created by Canxer on 8/10/2016.
 */
public class ViewFlatResultUI extends AppCompatActivity {


    MainMenu mainMenu;
    private ListView lv;
    private ArrayList<String> strArr;
    private ArrayAdapter<String> adapter;
    public String flatLocation;

    private String flatDesc="Nil";
    private String flatDetails="Nil";

    Button amenitiesButton;

    /**
     * This method will save the state of the application in a bundle
     *
     * @param savedInstanceState save state created previously
     */
    @Override
    public boolean onOptionsItemSelected(MenuItem item){
        int id = item.getItemId();
        if (id == R.id.Home) {
            Intent intent = new Intent(this,MainMenuUI.class);
            this.startActivity(intent);
            return true;
        }

        if (id == R.id.about) {
            Intent intent = new Intent(this,MenuAboutUs.class);
            this.startActivity(intent);
            return true;
        }
        if (id == R.id.contact) {
            Intent intent = new Intent(this,MenuContactUs.class);
            this.startActivity(intent);
            return true;

        }
        return super.onOptionsItemSelected(item);

    }
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_viewflatresult);
        Toolbar my_toolbar = (Toolbar) findViewById(R.id.my_toolbar);
        setSupportActionBar(my_toolbar);
        getSupportActionBar().setTitle(R.string.my_tb_title);
        getSupportActionBar().setSubtitle("View Flat Result");

        TextView textPrice=(TextView)findViewById(R.id.textViewPrice);
        TextView textDesc=(TextView)findViewById(R.id.textViewDesc);
        ImageView imageView = (ImageView)findViewById(R.id.imageView);


        flatDetails = getIntent().getStringExtra("textflatdetails");
        flatDesc = getIntent().getStringExtra("textLocation");


        if(flatDesc.equals("Bukit Panjang"))
        {
            textDesc.setText("Senja Gateway is a new residential estate located in the heart of Bukit Panjang. With close proximity to nearby amenities such as Bukit Panjang Plaza, Junction 10 as well as the Downtown line, it is the perfect choice for couples looking to build their own piece of heaven.");
            imageView.setImageResource(R.drawable.bpsenja);
        }
        else if(flatDesc.equals("Choa Chu Kang"))
        {
            textDesc.setText("ONE@CCK is a new residential estate located in the heart of Choa Chu Kang. With close proximity to nearby amenities such as Lot One Shoppers Mall, Choa Chu Kang Park as well as the Choa Chu Kang Mrt Station, it is the perfect choice for couples looking to build their own piece of heaven.");
            imageView.setImageResource(R.drawable.cckflat);
        }

        textPrice.setText(flatDetails);
    }

    public boolean onCreateOptionsMenu(Menu menu) {

        getMenuInflater().inflate(R.menu.menu, menu);
        return super.onCreateOptionsMenu(menu);
    }

    public void viewGrant(View view) {
        // Do something in response to button
        Intent intent = new Intent(this, GrantQueryUI.class);
        intent.putExtra("mainMenu", mainMenu);
        startActivity(intent);
    }

    public void viewRepayment(View view) {
        // Do something in response to button
        Intent intent = new Intent(this, RepaymentQueryUI.class);
        intent.putExtra("mainMenu", mainMenu);
        startActivity(intent);
    }

    public void viewFlats(View view) {
        // Do something in response to button
        Intent intent = new Intent(this, ViewFlatQueryUI.class);
        intent.putExtra("mainMenu", mainMenu);
        startActivity(intent);
    }

    public void amenitiesButton(View view) {

        String buttonAmenities;
        buttonAmenities = ((Button) view).getText().toString();
        if (buttonAmenities.equals("View Nearby Amenities")) {

            Intent i = new Intent(ViewFlatResultUI.this, ViewAmenities.class);
            i.putExtra("mainMenu", mainMenu);
            i.putExtra("textLocation", flatDesc);
            startActivity(i);
        }
        }
}


