package com.gjenterprise.canxer.btosg.Control;
import android.app.Activity;
import android.content.Context;
import android.content.Intent;

import com.gjenterprise.canxer.btosg.Boundary.GrantResultUI;

import java.io.*;

/**
 * Created by Canxer on 8/10/2016.
 */
public class GrantMgr extends Activity {

    public void GetGrantDetails(String app, String inc, String sal,Context context){
        String total="Nil";

        /*Calculate available query */
        switch(app){
            case "First-Timer Couple":
            case "Orphans Scheme":
            case "Joint Singles Scheme":{
                if(inc.equals("Up to $1,500")){
                    if(sal.equals("July 2013 to May 2015"))
                        total="$60,000";
                    else
                        total="$80,000";
                }
                else if(inc.equals("$1,501 to $2,000")){

                    if(sal.equals("July 2013 to May 2015"))
                        total="$55,000";
                    else
                        total="$75,000";
                }
                else if(inc.equals("$2,001 to $2,500")){

                    if(sal.equals("July 2013 to May 2015"))
                        total="$50,000";
                    else
                        total="$70,000";
                }
                else if(inc.equals("$$2,501 to $3,000")){

                    if(sal.equals("July 2013 to May 2015"))
                        total="$45,000";
                    else
                        total="$65,000";
                }
                else if(inc.equals("$3,001 to $3,500")){

                    if(sal.equals("July 2013 to May 2015"))
                        total="$40,000";
                    else
                        total="$60,000";
                }
                else if(inc.equals("$3,501 to $4,000")){

                    if(sal.equals("July 2013 to May 2015"))
                        total="$35,000";
                    else
                        total="$55,000";
                }
                else if(inc.equals("$4,001 to $4,500")){

                    if(sal.equals("July 2013 to May 2015"))
                        total="$30,000";
                    else
                        total="$50,000";
                }
                else if(inc.equals("$4,501 to $5,000")){

                    if(sal.equals("July 2013 to May 2015"))
                        total="$25,000";
                    else
                        total="$45,000";
                }
                else if(inc.equals("$5,001 to $5,500")){

                    if(sal.equals("July 2013 to May 2015"))
                        total="$15,000";
                    else
                        total="$35,000";
                }
                else if(inc.equals("$5,501 to $6,000")){

                    if(sal.equals("July 2013 to May 2015"))
                        total="$10,000";
                    else
                        total="$30,000";
                }
                else if(inc.equals("$6,001 to $6,500")){

                    if(sal.equals("July 2013 to May 2015"))
                        total="$5,000";
                    else
                        total="$25,000";
                }
                else if(inc.equals("$6,501 to $7,000")){

                    if(sal.equals("July 2013 to May 2015"))
                        total="Nil";
                    else
                        total="$20,000";
                }
                else if(inc.equals("$7,001 to $7,500")){

                    if(sal.equals("July 2013 to May 2015"))
                        total="Nil";
                    else
                        total="$15,000";
                }
                else if(inc.equals("$7,501 to $8,000")){
                    if(sal.equals("July 2013 to May 2015"))
                        total="Nil";
                    else
                        total="$10,000";
                }
                else if(inc.equals("$8,001 to $8,500")){
                    if(sal.equals("July 2013 to May 2015"))
                        total="Nil";
                    else
                        total="$5,000";
                }

            }
            break;
            case "Non-Citizen Spouse":
            case "First-Timer and Second-Timer Couple":
            case "Single Singapore Citizen":{
                if(inc.equals("Up to $750")){
                    if(sal.equals("July 2013 to May 2015"))
                        total="$30,000";
                    else
                        total="$40,000";
                }
                else if(inc.equals("$751 to $1,000")){

                    if(sal.equals("July 2013 to May 2015"))
                        total="$27,500";
                    else
                        total="$37,500";
                }
                else if(inc.equals("$1,001 to $1,250")){

                    if(sal.equals("July 2013 to May 2015"))
                        total="$25,000";
                    else
                        total="$35,000";
                }
                else if(inc.equals("$1,251 to $1,500")){

                    if(sal.equals("July 2013 to May 2015"))
                        total="$22,500";
                    else
                        total="$32,500";
                }
                else if(inc.equals("$1,501 to $1,750")){

                    if(sal.equals("July 2013 to May 2015"))
                        total="$20,000";
                    else
                        total="$30,000";
                }
                else if(inc.equals("$1,751 to $2,000")){

                    if(sal.equals("July 2013 to May 2015"))
                        total="$17,500";
                    else
                        total="$27,500";
                }
                else if(inc.equals("$2,001 to $2,250")){

                    if(sal.equals("July 2013 to May 2015"))
                        total="$15,000";
                    else
                        total="$25,000";
                }
                else if(inc.equals("$2,251 to $2,500")){

                    if(sal.equals("July 2013 to May 2015"))
                        total="$12,500";
                    else
                        total="$22,500";
                }
                else if(inc.equals("$2,501 to $2,750")){

                    if(sal.equals("July 2013 to May 2015"))
                        total="$7,500";
                    else
                        total="$17,500";
                }
                else if(inc.equals("$2,751 to $3,000")){

                    if(sal.equals("July 2013 to May 2015"))
                        total="$5,000";
                    else
                        total="$15,000";
                }
                else if(inc.equals("$3,001 to $3,250")){

                    if(sal.equals("July 2013 to May 2015"))
                        total="$2,500";
                    else
                        total="$12,500";
                }
                else if(inc.equals("$3,251 to $3,500")){

                    if(sal.equals("July 2013 to May 2015"))
                        total="Nil";
                    else
                        total="$10,000";
                }
                else if(inc.equals("$3,501 to $3,750")){

                    if(sal.equals("July 2013 to May 2015"))
                        total="Nil";
                    else
                        total="$7,500";
                }
                else if(inc.equals("$3,751 to $4,000")){
                    if(sal.equals("July 2013 to May 2015"))
                        total="Nil";
                    else
                        total="$5,000";
                }
                else if(inc.equals("$4,001 to $4,250")){
                    if(sal.equals("July 2013 to May 2015"))
                        total="Nil";
                    else
                        total="$2,500";
                }
            }
            break;
            default:
                System.out.println("Error");
        }

        Intent intent = new Intent(context,GrantResultUI.class);
        intent.putExtra("grantAmt",total);
        context.startActivity(intent);
    }

}

