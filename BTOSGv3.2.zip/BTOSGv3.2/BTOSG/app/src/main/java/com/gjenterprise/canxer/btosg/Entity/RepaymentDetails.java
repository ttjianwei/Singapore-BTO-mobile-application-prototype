package com.gjenterprise.canxer.btosg.Entity;

/**
 * Created by HaoZhe on 25/10/2016.
 */

public class RepaymentDetails {
}
