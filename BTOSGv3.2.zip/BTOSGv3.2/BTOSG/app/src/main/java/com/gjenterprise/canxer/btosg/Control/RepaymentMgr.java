package com.gjenterprise.canxer.btosg.Control;

import com.gjenterprise.canxer.btosg.Boundary.RepaymentQueryUI;

public class RepaymentMgr {

    public static Double makeCalculation(String amount,String years, String type) {
        double monthlyRepayment = 0;
        String loanType = type;
        if(loanType.equals("Housing Loan")) {
            double amt = Double.parseDouble(amount);
            double year = Double.parseDouble(years);
            double interestRate = 0.001;
            monthlyRepayment = (amt * (Math.pow((1 + interestRate), 1 * year))) / (12 * year);
        }
        else if (loanType.equals("Bank Loan"))
        {
            double amt = Double.parseDouble(amount);
            double year = Double.parseDouble(years);
            double interestRate = 0.1;
            monthlyRepayment = (amt * (Math.pow((1 + interestRate), 1 * year))) / (12 * year);
        }
        return monthlyRepayment ;
    }
}