package com.gjenterprise.canxer.btosg.Boundary;

/**
 * Created by HaoZhe on 7/11/2016.
 */
import android.app.Activity;
import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.Toolbar;
import android.text.Html;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;
import android.widget.ImageView;

import com.gjenterprise.canxer.btosg.Control.MainMenu;
import com.gjenterprise.canxer.btosg.R;
import com.google.android.gms.common.ConnectionResult;
import com.google.android.gms.common.api.GoogleApiClient;
import com.google.android.gms.common.api.ResultCallback;
import com.google.android.gms.common.GooglePlayServicesNotAvailableException;
import com.google.android.gms.common.GooglePlayServicesRepairableException;
import com.google.android.gms.location.places.Place;
import com.google.android.gms.location.places.PlacePhotoMetadataResult;
import com.google.android.gms.location.places.PlacePhotoMetadataBuffer;
import com.google.android.gms.location.places.PlacePhotoResult;
import com.google.android.gms.location.places.Places;
import com.google.android.gms.location.places.ui.PlacePicker;
import com.google.android.gms.maps.model.LatLng;
import com.google.android.gms.maps.model.LatLngBounds;


public class ViewAmenities extends AppCompatActivity implements GoogleApiClient.ConnectionCallbacks, GoogleApiClient.OnConnectionFailedListener {
    private static final int PLACE_PICKER_REQUEST = 1;
    private TextView mName;
    private TextView mAddress;
    private TextView mPhone;
    private TextView mRating;
    private TextView mWeb;
    private TextView mAttributions;
    private ImageView placePhoto;
    private GoogleApiClient mGoogleApiClient = null;
    MainMenu mainMenu;

    double bp1 = 1.3790352;
    double bp2 = 103.7630716;
    double bp3 = 1.3800001;
    double bp4 = 103.7644;
    double cck1 = 1.386742;
    double cck2 = 103.7456552;
    double cck3 = 1.385350;
    double cck4 = 103.744599 ;
    private String flatDesc="Nil";



    private LatLngBounds BukitPanjang = new LatLngBounds(
            new LatLng(1.3790352, 103.7630716), new LatLng(1.3800001, 103.7644));
    private LatLngBounds ChoaChuKang = new LatLngBounds(
            new LatLng(cck3, cck4), new LatLng(cck1, cck2));

    @Override
    public boolean onOptionsItemSelected(MenuItem item){
        int id = item.getItemId();
        if (id == R.id.Home) {
            Intent intent = new Intent(this,MainMenuUI.class);
            this.startActivity(intent);
            return true;
        }

        if (id == R.id.about) {
            Intent intent = new Intent(this,MenuAboutUs.class);
            this.startActivity(intent);
            return true;
        }
        if (id == R.id.contact) {
            Intent intent = new Intent(this,MenuContactUs.class);
            this.startActivity(intent);
            return true;

        }
        return super.onOptionsItemSelected(item);
    }
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_viewamenities);


        Toolbar my_toolbar = (Toolbar) findViewById(R.id.my_toolbar);
        setSupportActionBar(my_toolbar);

        getSupportActionBar().setTitle(R.string.my_tb_title);
        getSupportActionBar().setSubtitle("View Amenities");
        mGoogleApiClient = new GoogleApiClient.Builder(this).addApi(Places.GEO_DATA_API).addApi(Places.PLACE_DETECTION_API).enableAutoManage(this,this).build();

        placePhoto = (ImageView) findViewById(R.id.imageView2);
        mName = (TextView) findViewById(R.id.textViewName);
        mAddress = (TextView) findViewById(R.id.textViewAddress);
        mPhone = (TextView) findViewById(R.id.textViewPhone);
        mWeb = (TextView) findViewById(R.id.textViewWeb);
        mAttributions = (TextView) findViewById(R.id.textViewAtt);

        flatDesc = getIntent().getStringExtra("textLocation");

        Button pickerButton = (Button) findViewById(R.id.pickerButton);
        pickerButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (flatDesc.equals("Bukit Panjang")) {
                try {
                    PlacePicker.IntentBuilder intentBuilder =
                            new PlacePicker.IntentBuilder();
                    intentBuilder.setLatLngBounds(BukitPanjang);
                    Intent intent = intentBuilder.build(ViewAmenities.this);
                    startActivityForResult(intent, PLACE_PICKER_REQUEST);

                } catch (GooglePlayServicesRepairableException
                        | GooglePlayServicesNotAvailableException e) {
                    e.printStackTrace();
                }
            }
                else if (flatDesc.equals("Choa Chu Kang"))
                {
                    try {
                        PlacePicker.IntentBuilder intentBuilder =
                                new PlacePicker.IntentBuilder();
                        intentBuilder.setLatLngBounds(ChoaChuKang);
                        Intent intent = intentBuilder.build(ViewAmenities.this);
                        startActivityForResult(intent, PLACE_PICKER_REQUEST);

                    } catch (GooglePlayServicesRepairableException
                            | GooglePlayServicesNotAvailableException e) {
                        e.printStackTrace();
                    }
                }
            }
        });

    }
    @Override
    public boolean onCreateOptionsMenu(Menu menu) {

        getMenuInflater().inflate(R.menu.menu, menu);
        return super.onCreateOptionsMenu(menu);
    }

    @Override
    protected void onActivityResult(int requestCode,
                                    int resultCode, Intent data) {

        if (requestCode == PLACE_PICKER_REQUEST
                && resultCode == Activity.RESULT_OK) {

            final Place place = PlacePicker.getPlace(this, data);
            final CharSequence name = place.getName();
            final CharSequence address = place.getAddress();
            final CharSequence phone = place.getPhoneNumber();

            try {
                final Uri web = place.getWebsiteUri();
                mWeb.setText(web.toString());
            }
            catch(Exception e){
                mWeb.setText("Website of location is not available");
                return;
            }

            final String placeID = place.getId();



            //final float rating = place.getRating();
            String attributions = (String) place.getAttributions();
            if (attributions == null) {
                attributions = "";
            }

            mName.setText(name);
            mAddress.setText(address);
            mPhone.setText(phone);
            placePhotoAsync(placeID,mGoogleApiClient);
            mAttributions.setText(Html.fromHtml(attributions));

        } else {
            super.onActivityResult(requestCode, resultCode, data);
        }
    }

    @Override
    public void onConnected(Bundle bundle) {

    }
    public void onConnectionSuspended(int i) {

    }
    public void onConnectionFailed(ConnectionResult connectionResult) {

    }

    private ResultCallback<PlacePhotoResult> mDisplayPhotoResultCallback = new ResultCallback<PlacePhotoResult>(){

        @Override
        public void onResult(PlacePhotoResult placePhotoResult){
            if(!placePhotoResult.getStatus().isSuccess()){

                return;
            }
            placePhoto.setImageBitmap(placePhotoResult.getBitmap());
        }
    };

    private void placePhotoAsync(String placeID, final GoogleApiClient mGoogleApiClient){
        //final String placeId = "ChIJrTLr-GyuEmsRBfy61i59si0"; // Australian Cruise Group
        Places.GeoDataApi.getPlacePhotos(mGoogleApiClient, placeID).setResultCallback(new ResultCallback<PlacePhotoMetadataResult>() {


            @Override
            public void onResult(PlacePhotoMetadataResult photos) {
                if (!photos.getStatus().isSuccess()) {
                    return;
                }
                final GoogleApiClient apiClients = mGoogleApiClient;
                PlacePhotoMetadataBuffer photoMetadataBuffer = photos.getPhotoMetadata();
                if (photoMetadataBuffer.getCount() > 0) {
                    // Display the first bitmap in an ImageView in the size of the view
                    photoMetadataBuffer.get(0).getScaledPhoto(apiClients, placePhoto.getWidth(),
                            placePhoto.getHeight())
                            .setResultCallback(mDisplayPhotoResultCallback);
                }
                else
                    placePhoto.setImageResource(R.drawable.nopic);
                photoMetadataBuffer.release();
            }
        });

    }

    public void viewGrant(View view) {
        // Do something in response to button
        Intent intent = new Intent(this,GrantQueryUI.class);
        intent.putExtra("mainMenu", mainMenu);
        startActivity(intent);
    }
    public void viewRepayment(View view) {
        // Do something in response to button
        Intent intent = new Intent(this,RepaymentQueryUI.class);
        intent.putExtra("mainMenu", mainMenu);
        startActivity(intent);
    }
    public void viewFlats(View view) {
        // Do something in response to button
        Intent intent = new Intent(this,ViewFlatQueryUI.class);
        intent.putExtra("mainMenu", mainMenu);
        startActivity(intent);
    }
}