package com.gjenterprise.canxer.btosg.Entity;

import android.os.Parcel;
import android.os.Parcelable;

import java.util.ArrayList;
import java.util.List;

/**
 * Created by Canxer on 8/10/2016.
 */
public class FlatCollection implements Parcelable {
    private List<FlatDetails> collection;

    public FlatCollection() {
    }

    public FlatCollection(List<FlatDetails> collection) {
        this.collection = collection;
    }

    public FlatCollection(Parcel in){
//        collection = new ArrayList<FlatDetails>();
        this.collection = in.readArrayList(FlatDetails.class.getClassLoader());
    }

    public List<FlatDetails> getCollection() {
        return collection;
    }

    public void setCollection(ArrayList<FlatDetails> collection) {
        this.collection = collection;
    }

    // This method is required for parcelable
    // For not return 0
    @Override
    public int describeContents() {
        return 0;
    }

    @Override
    public void writeToParcel(Parcel dest, int flags) {
        dest.writeList(collection);

    }

    public static Parcelable.Creator<FlatCollection> CREATOR = new Parcelable.Creator<FlatCollection>(){

        @Override
        public FlatCollection createFromParcel (Parcel source){
            return new FlatCollection(source);
        }
        public FlatCollection[] newArray(int size) {
            return new FlatCollection[size];
        }
    };
}

