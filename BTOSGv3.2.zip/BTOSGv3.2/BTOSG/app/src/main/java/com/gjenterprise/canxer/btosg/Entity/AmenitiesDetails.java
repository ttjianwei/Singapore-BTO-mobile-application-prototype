package com.gjenterprise.canxer.btosg.Entity;

/**
 * Created by Canxer on 8/10/2016.
 */
public class AmenitiesDetails {
}
