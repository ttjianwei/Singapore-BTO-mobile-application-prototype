package com.gjenterprise.canxer.btosg.Entity;

import android.os.Parcel;
import android.os.Parcelable;

import java.lang.reflect.Array;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
/**
 * Created by Canxer on 8/10/2016.
 */
public class FlatDetails implements Parcelable {


        private int id;
        private int financial_year;
        private String town;
        private String room_type;
        private int min_selling_price;
        private int max_selling_price;
        private String min_selling_price_ahg;
        private String max_selling_price_ahg;
        private String address;

        public FlatDetails()
        {

        }

        public FlatDetails(int id, int financial_year, String town, String room_type, int min_selling_price, int max_selling_price, String min_selling_price_ahg, String max_selling_price_ahg) {
            this.id = id;
            this.financial_year = financial_year;
            this.town = town;
            this.room_type = room_type;
            this.min_selling_price = min_selling_price;
            this.max_selling_price = max_selling_price;
            this.min_selling_price_ahg = min_selling_price_ahg;
            this.max_selling_price_ahg = max_selling_price_ahg;
            this.setaddress();
        }

        /**
         * Contructor for when using parcelable to pass object between activities
         * @param in
         */
        public FlatDetails(Parcel in){
            this.id = in.readInt();
            this.financial_year = in.readInt();
            this.town = in.readString();
            this.room_type = in.readString();
            this.min_selling_price = in.readInt();
            this.max_selling_price = in.readInt();
            this.min_selling_price_ahg = in.readString();
            this.max_selling_price_ahg = in.readString();
            this.address = in.readString();
        }

        // Set
        public void setId(int id)
        {
            this.id = id;
        }
        public void setFinancial_year(int financial_year)
        {
            this.financial_year = financial_year;
        }
        public void setTown(String town)
        {
            this.town = town;
        }
        public void setRoom_type(String room_type)
        {
            this.room_type = room_type;
        }
        public void setMin_selling_price(int min_selling_price)
        {
            this.min_selling_price = min_selling_price;
        }
        public void setMax_selling_price(int max_selling_price)
        {
            this.max_selling_price = max_selling_price;
        }
        public void setMin_selling_price_ahg(String min_selling_price_ahg)
        {
            this.min_selling_price_ahg = min_selling_price_ahg;
        }
        public void setMax_selling_price_ahg(String max_selling_price_ahg)
        {
            this.max_selling_price_ahg = max_selling_price_ahg;
        }

        //Get
        public int getId()
        {
            return id;
        }
        public int getFinancial_year()
        {
            return financial_year;
        }
        public String getTown()
        {
            return town;
        }
        public String getRoom_type()
        {
            return room_type;
        }
        public int getMin_selling_price()
        {
            return min_selling_price;
        }
        public int getMax_selling_price()
        {
            return max_selling_price;
        }
        public String getMin_selling_price_ahg()
        {
            return min_selling_price_ahg;
        }
        public String getMax_selling_price_ahg()
        {
            return max_selling_price_ahg;
        }

        public void setAddress(String address){
            this.address = address;
        }

        public String getAddress (){
            return this.address;
        }

        @Override
        public int describeContents() {
            return 0;
        }

        @Override
        public void writeToParcel(Parcel dest, int flags) {
            dest.writeInt(id);
            dest.writeInt(financial_year);
            dest.writeString(town);
            dest.writeString(room_type);
            dest.writeInt(min_selling_price);
            dest.writeInt(max_selling_price);
            dest.writeString(min_selling_price_ahg);
            dest.writeString(max_selling_price_ahg);
            dest.writeString(address);
        }

        private void setaddress(){
            List<String> Punggol;
            List<String> SengKang;
            List<String> JurongWest;
            List<String> BukitPanjang;
            List<String> Woodlands;
            List<String> ChoaChuKang;
            List<String> Yishun;
            List<String> Sembawang;

            Punggol = Arrays.asList("315 Punggol Dr","266 Punggol Way","174D Edgedale Plains ",
                    "271 Punggol Walk","101B Punggol Field","622 Punggol Central");
            SengKang = Arrays.asList("224B Compassvale Walk","215 Jalan Kayu","317A Anchorvale Rd",
                    "194 Rivervale Dr","143 Rivervale Dr","50 Sengkang Square");
            Sembawang = Arrays.asList("30 Sembawang Dr","604 Sembawang Rd");
            JurongWest = Arrays.asList("714 Jurong West Street 71","813 Jurong West Street 81",
                    "1 Jurong West Ave 2");
            ChoaChuKang = Arrays.asList("309 Choa Chu Kang Avenue 4","329 Choa Chu Kang Avenue 3",
                    "2A Hong San Walk","253 Choa Chu Kang Avenue 1");
            BukitPanjang = Arrays.asList("105 Cashew Rd","Blk 487 Segar Rd",
                    "50 Cashew Rd","31 Bangkit Rd");
            Yishun = Arrays.asList("156 Yishun Street 11","219 Yishun Street 21","748 Yishun Street 72");
            Woodlands = Arrays.asList("30 Woodlands Avenue 2","1 Rosewood Dr",
                    "71 Woodgrove Ave","3 Woodgrove Dr","15 Marsiling Ln");


            if(town.equals("Punggol")){
                switch (financial_year){
                    case 2008: this.address = Punggol.get(0);
                        break;
                    case 2009: this.address = Punggol.get(1);
                        break;
                    case 2010: this.address = Punggol.get(2);
                        break;
                    case 2011: this.address = Punggol.get(3);
                        break;
                    case 2012: this.address = Punggol.get(4);
                        break;
                    case 2013: this.address = Punggol.get(5);
                        break;
                    default: break;
                }
            } else if(town.equals("Sengkang")){
                switch (financial_year){
                    case 2008: this.address = SengKang.get(0);
                        break;
                    case 2009: this.address = SengKang.get(1);
                        break;
                    case 2010: this.address = SengKang.get(2);
                        break;
                    case 2011: this.address = SengKang.get(3);
                        break;
                    case 2012: this.address = SengKang.get(4);
                        break;
                    case 2013: this.address = SengKang.get(5);
                        break;
                    default: break;
                }
            } else if(town.equals("Sembawang")) {
                switch (financial_year) {
                    case 2011:
                        this.address = Sembawang.get(0);
                        break;
                    case 2013:
                        this.address = Sembawang.get(1);
                        break;
                    default:
                        break;
                }
            }else if(town.equals("Jurong West")){
                switch (financial_year) {
                    case 2008:
                        this.address = JurongWest.get(0);
                        break;
                    case 2009:
                        this.address = JurongWest.get(1);
                        break;
                    case 2010:
                        this.address = JurongWest.get(2);
                    default:
                        break;
                }
            }else if(town.equals("Bukit Panjang")){
                switch (financial_year){
                    case 2008: this.address = BukitPanjang.get(0);
                        break;
                    case 2009: this.address = BukitPanjang.get(1);
                        break;
                    case 2010: this.address = BukitPanjang.get(2);
                        break;
                    case 2011: this.address = BukitPanjang.get(3);
                        break;
                    default: break;
                }
            }else if(town.equals("Yishun")){
                switch (financial_year){
                    case 2011: this.address = Yishun.get(0);
                        break;
                    case 2012: this.address = Yishun.get(1);
                        break;
                    case 2013: this.address = Yishun.get(2);
                        break;
                    default: break;
                }
            }else if(town.equals("Woodlands")){
                switch (financial_year){
                    case 2008: this.address = Woodlands.get(0);
                        break;
                    case 2009: this.address = Woodlands.get(1);
                        break;
                    case 2010: this.address = Woodlands.get(2);
                        break;
                    case 2012: this.address = Woodlands.get(3);
                        break;
                    case 2013: this.address = Woodlands.get(4);
                        break;
                    default: break;
                }
            }else if(town.equals("Choa Chu Kang")){
                switch (financial_year){
                    case 2009: this.address = ChoaChuKang.get(0);
                        break;
                    case 2011: this.address = ChoaChuKang.get(1);
                        break;
                    case 2012: this.address = ChoaChuKang.get(2);
                        break;
                    case 2013: this.address = ChoaChuKang.get(3);
                        break;
                    default: break;
                }
            }
        }

        public static Parcelable.Creator<FlatDetails> CREATOR = new Parcelable.Creator<FlatDetails>(){

            @Override
            public FlatDetails createFromParcel (Parcel source){
                return new FlatDetails(source);
            }
            public FlatDetails[] newArray(int size) {
                return new FlatDetails[size];
            }
        };
}
