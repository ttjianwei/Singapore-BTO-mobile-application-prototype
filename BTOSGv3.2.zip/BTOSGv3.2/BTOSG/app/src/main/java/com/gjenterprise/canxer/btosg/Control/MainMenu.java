package com.gjenterprise.canxer.btosg.Control;

import android.os.Parcel;
import android.os.Parcelable;

import com.gjenterprise.canxer.btosg.Entity.FlatCollection;
import com.gjenterprise.canxer.btosg.Entity.GrantDetails;
import com.gjenterprise.canxer.btosg.Entity.RepaymentDetails;
import com.gjenterprise.canxer.btosg.Entity.InputStore;

/**
 * Created by Canxer on 8/10/2016.
 */
public class MainMenu implements Parcelable{
    private InputStore inputs;
    private FlatCollection flatCollection;
    private GrantDetails grantDetails;
    private RepaymentDetails repayDetails;
    private ViewFlatMgr viewFlatMgr;
    private GrantMgr grantMgr;
    private RepaymentMgr repaymentMgr;


    //Constructor
    public MainMenu(InputStore inputs,
                    FlatCollection flatCollection,
                    GrantDetails grantDetails,
                    RepaymentDetails repayDetails,
                    ViewFlatMgr viewFlatMgr,
                    GrantMgr grantMgr,
                    RepaymentMgr repaymentMgr
    ){
        this.inputs = inputs;
        this.flatCollection = flatCollection;
        this.repayDetails = repayDetails;
        this.grantDetails = grantDetails;
        this.viewFlatMgr = viewFlatMgr;
        this.grantMgr = grantMgr;
        this.repaymentMgr = repaymentMgr;
    }

    public MainMenu(Parcel in){
        this.inputs = in.readParcelable(InputStore.class.getClassLoader());
        this.flatCollection = in.readParcelable(FlatCollection.class.getClassLoader());
        this.repayDetails = in.readParcelable(RepaymentDetails.class.getClassLoader());
        this.grantDetails = in.readParcelable(GrantDetails.class.getClassLoader());
        this.viewFlatMgr = in.readParcelable(ViewFlatMgr.class.getClassLoader());
        this.grantMgr = in.readParcelable(GrantMgr.class.getClassLoader());
        this.repaymentMgr = in.readParcelable(RepaymentMgr.class.getClassLoader());
    }
    public InputStore getInputs(){
        return this.inputs;
    }

    public FlatCollection getFlatCollection(){
        return this.flatCollection;
    }

    public GrantDetails getGrantDetails(){
        return this.grantDetails;
    }

    public RepaymentDetails getRepaymentDetails(){
        return this.repayDetails;
    }

    // This handle the events when user choose to search for available flats (ViewHDBFlat)
    public void updateMonthlyIncome(double monthlyIncome) {
        this.inputs.setMonthlyIncome(monthlyIncome);
    }
    public void updateAmtRepay(double amtRepay) {
        this.inputs.setAmtRepay(amtRepay);
    }
    public void updateYearToPay(int yearToPay) {
        this.inputs.setSelectedYears(yearToPay);
    }
    public void updateLoanAmt(double loanAmt) {
        this.inputs.setSelectedLoan(loanAmt);
    }
    public void updateTypeOfGrant(String typeOfGrant) {
        this.inputs.setTypeOfGrant(typeOfGrant);
    }
    public void updateSelectedSale(boolean selectedSale) {
        this.inputs.setSelectedSale(selectedSale);
    }
    public void updateSelectedRoomType(String selectedRoomType) {
        this.inputs.setSelectedRoomType(selectedRoomType);
    }
    public void updateRegion(String region){
        this.inputs.setRegion(region);
    }
    public void updatePriceRange(String priceRange) {
        this.inputs.setPriceRange(priceRange);
    }

    /*public void processViewHDBFlat(){
        InputStore inputs = this.inputs;
        this.viewFlatMgr.findFlats(inputs);
    }*/

    public String getSelectedRoomType(){
        return inputs.getSelectedRoomType();
    }
    public String getSelectedLocation(){
        return inputs.getRegion();
    }
    public String getSelectedPriceRange(){
        return inputs.getPriceRange();
    }

    public String getSelectedTypeOfApplicant(){
        return inputs.getSelectedTypeOfApplicant();
    }
    public String getSelectedMonthlyIncome(){
        return inputs.getSelectedGrantMonthlyIncome();
    }

    public String getSelectedSalesLaunch(){
        return inputs.getSelectedSalesLaunch();
    }

    public double getSelectedLoan(){
        return inputs.getSelectedLoan();
    }

    public int getSelectedYears(){
        return inputs.getSelectedYears();
    }

    /*public ArrayList<String> findAvailFlats(){
        ArrayList<String> result = new ArrayList<>();
        List<FlatDetails> resultList = viewFlatMgr.findFlats(inputs);
        for(FlatDetails BTO : resultList){
           result.add(BTO.getTown() + ", " + BTO.getAddress() + "\n" + BTO.getRoom_type() + " " + BTO.getMin_selling_price() + " - " + BTO.getMax_selling_price());
        }
        return result;
    }*/
   /* public ArrayList<String> findAffordFlats(){
        ArrayList<String> result = new ArrayList<>();
        List<HDBFlat> resultList = affordableFlatController.findAffordableFlats(inputs);
        for(HDBFlat hdb : resultList){
            result.add(hdb.getTown() + ", " + hdb.getAddress() + "\n" + hdb.getRoomType() + " " + hdb.getMinPrice() + " - " + hdb.getMaxPrice());
        }
        return result;
    }*/

    /*public String findGrant(){
        return grantMgr.findGrant(inputs);
    }*/

    /*public double findMonthlyRepayment(){
        debtRepayDetails = debtController.calMonthlyRepayment(inputs);
        return debtRepayDetails.getMonthlyRepayment();
    }*/



    @Override
    public int describeContents() {
        return 0;
    }

    public void setAvailFlatInputs(String selectedRoomType, String selectedLocation, String selectedPriceRange){
        inputs.setSelectedRoomType(selectedRoomType);
        inputs.setRegion(selectedLocation);
        inputs.setPriceRange(selectedPriceRange);
    }

    public void setAffordFlatInputs(double monthlyInstallment, int repaymentPeriod){
        inputs.setMonthlyIncome(monthlyInstallment);
        inputs.setSelectedYears(repaymentPeriod);
    }

    public void setGrantInfo(String selectedTypeOfApplicant, String selectedGrantMonthlyIncome, String selectedSalesLaunch){
        inputs.setSelectedTypeOfApplicant(selectedTypeOfApplicant);
        inputs.setSelectedGrantMonthlyIncome(selectedGrantMonthlyIncome);
        inputs.setSelectedSalesLaunch(selectedSalesLaunch);
    }

    public void setDebtInputs(double selectedLoan, int selectedYears){
        inputs.setSelectedLoan(selectedLoan);
        inputs.setSelectedYears(selectedYears);
    }

    @Override
    public void writeToParcel(Parcel dest, int flags) {
        dest.writeParcelable(inputs, flags);
        dest.writeParcelable(flatCollection, flags);
        //dest.writeParcelable(repayDetails, flags);
        //dest.writeParcelable(grantDetails, flags);
       // dest.writeParcelable(viewFlatMgr, flags);
        //dest.writeParcelable(grantMgr, flags);
        //dest.writeParcelable(repaymentMgr, flags);
    }



    public static Parcelable.Creator<MainMenu> CREATOR = new Parcelable.Creator<MainMenu>(){

        @Override
        public MainMenu createFromParcel (Parcel source){
            return new MainMenu(source);
        }
        public MainMenu[] newArray(int size) {
            return new MainMenu[size];
        }
    };
}

