package com.gjenterprise.canxer.btosg.Boundary;

import android.content.Intent;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.Toolbar;
import android.view.MenuItem;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.ListView;

import android.widget.Button;
import android.widget.Spinner;



import android.view.Menu;

import com.gjenterprise.canxer.btosg.Control.ApiMgr;
import com.gjenterprise.canxer.btosg.Control.MainMenu;
import com.gjenterprise.canxer.btosg.Entity.DbHandler;
import com.gjenterprise.canxer.btosg.Entity.FlatDetails;
import com.gjenterprise.canxer.btosg.R;


import java.util.ArrayList;

/**
 * Created by Canxer on 8/10/2016.
 */
public class ViewFlatQueryUI extends AppCompatActivity {

    ArrayAdapter<CharSequence> roomTypeAdapter;
    ArrayAdapter<CharSequence> locationAdapter;
    ArrayAdapter<CharSequence> priceRangeAdapter;

    Spinner roomTypeSpinner;
    Spinner locationSpinner;
    Spinner priceRangeSpinner;
    Button searchButton;

    ApiMgr apiMgr;
    FlatDetails flats;
    DbHandler handler;
    MainMenu mainMenu;


    String textRoom="1 Room";
    String textLocation="Bukit Panjang";
    String textPriceRange="50,001 - 200,000";

    private ListView lv;
    String[] test;
    private ArrayList<String> strArr;
    private ArrayAdapter<String> adapter;

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {

        getMenuInflater().inflate(R.menu.menu, menu);
        return super.onCreateOptionsMenu(menu);
    }
    @Override
    public boolean onOptionsItemSelected(MenuItem item){
        int id = item.getItemId();
        if (id == R.id.Home) {
            Intent intent = new Intent(this,MainMenuUI.class);
            this.startActivity(intent);
            return true;
        }

        if (id == R.id.about) {
            Intent intent = new Intent(this,MenuAboutUs.class);
            this.startActivity(intent);
            return true;
        }
        if (id == R.id.contact) {
            Intent intent = new Intent(this,MenuContactUs.class);
            this.startActivity(intent);
            return true;

        }
        return super.onOptionsItemSelected(item);

    }

    public void viewGrant(View view) {
        // Do something in response to button
        Intent intent = new Intent(this, GrantQueryUI.class);
        intent.putExtra("mainMenu", mainMenu);
        startActivity(intent);
    }

    public void viewRepayment(View view) {
        // Do something in response to button
        Intent intent = new Intent(this, RepaymentQueryUI.class);
        intent.putExtra("mainMenu", mainMenu);
        startActivity(intent);
    }

    public void viewFlats(View view) {
        // Do something in response to button
        Intent intent = new Intent(this, ViewFlatQueryUI.class);
        intent.putExtra("mainMenu", mainMenu);
        startActivity(intent);
    }


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_viewflatquery);

        Toolbar my_toolbar = (Toolbar) findViewById(R.id.my_toolbar);
        setSupportActionBar(my_toolbar);
        getSupportActionBar().setTitle(R.string.my_tb_title);
        getSupportActionBar().setSubtitle("View Flat Query");

        roomTypeSpinner = (Spinner) findViewById(R.id.spinner_roomtype);
        locationSpinner = (Spinner) findViewById(R.id.spinner_location);
        priceRangeSpinner = (Spinner) findViewById(R.id.spinner_price);

        searchButton = (Button) findViewById(R.id.button_searchBTO);

        roomTypeAdapter = ArrayAdapter.createFromResource(this, R.array.room_type, android.R.layout.simple_spinner_item);
        roomTypeAdapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        roomTypeSpinner.setAdapter(roomTypeAdapter);
        roomTypeSpinner.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
                // Toast.makeText(getBaseContext(), parent.getItemIdAtPosition(position) + " selected", Toast.LENGTH_SHORT).show();

            }

            @Override
            public void onNothingSelected(AdapterView<?> parent) {

            }
        });
        locationAdapter = ArrayAdapter.createFromResource(this, R.array.location, android.R.layout.simple_spinner_item);
        locationAdapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        locationSpinner.setAdapter(locationAdapter);
        locationSpinner.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {

            @Override
            public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {

            }

            @Override
            public void onNothingSelected(AdapterView<?> parent) {

            }
        });

        priceRangeAdapter = ArrayAdapter.createFromResource(this, R.array.price_range, android.R.layout.simple_spinner_item);
        priceRangeAdapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        priceRangeSpinner.setAdapter(priceRangeAdapter);
        priceRangeSpinner.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {

            }

            @Override
            public void onNothingSelected(AdapterView<?> parent) {
            }
        });
    }
// METHODS TO RECORD CHECKBOXES AND SPINNER CHOSEN AS USER INPUTS

    /**
     * This method navigates the searchButton to FlatAvailableResults
     *
     * @param view stores what the user interact with the button
     */
    public void searchButton(View view) {

        textRoom=roomTypeSpinner.getSelectedItem().toString();
        textLocation=locationSpinner.getSelectedItem().toString();
        textPriceRange=priceRangeSpinner.getSelectedItem().toString();

        String buttonSearch;
        buttonSearch = ((Button) view).getText().toString();
        if (buttonSearch.equals("Search")) {
            if(textLocation.equals("Bukit Panjang")) {
                if(textPriceRange.equals("50,001 - 200,000")) {
                    if(textRoom.equals("1 Room"))
                    {
                        test = getResources().getStringArray(R.array.bp1room50);
                    }
                    else if (textRoom.equals("2 Room"))
                    {
                        test = getResources().getStringArray(R.array.bp2room50);
                    }
                    else if (textRoom.equals("3 Room"))
                    {
                        test = getResources().getStringArray(R.array.nodata);
                    }
                    else if (textRoom.equals("4 Room"))
                    {
                        test = getResources().getStringArray(R.array.nodata);
                    }
                    else if (textRoom.equals("5 Room"))
                    {
                        test = getResources().getStringArray(R.array.nodata);
                    }
                }
                if(textPriceRange.equals("200,001 - 350,000")) {
                    if(textRoom.equals("1 Room"))
                    {
                        test = getResources().getStringArray(R.array.nodata);
                    }
                    else if (textRoom.equals("2 Room"))
                    {
                        test = getResources().getStringArray(R.array.bp2room200);
                    }
                    else if (textRoom.equals("3 Room"))
                    {
                        test = getResources().getStringArray(R.array.bp3room200);
                    }
                    else if (textRoom.equals("4 Room"))
                    {
                        test = getResources().getStringArray(R.array.nodata);
                    }
                    else if (textRoom.equals("5 Room"))
                    {
                        test = getResources().getStringArray(R.array.nodata);
                    }
                }
                if(textPriceRange.equals("350,001 - 500,000")) {
                    if(textRoom.equals("1 Room"))
                    {
                        test = getResources().getStringArray(R.array.nodata);
                    }
                    else if (textRoom.equals("2 Room"))
                    {
                        test = getResources().getStringArray(R.array.nodata);
                    }
                    else if (textRoom.equals("3 Room"))
                    {
                        test = getResources().getStringArray(R.array.bp3room350);
                    }
                    else if (textRoom.equals("4 Room"))
                    {
                        test = getResources().getStringArray(R.array.bp4room350);
                    }
                    else if (textRoom.equals("5 Room"))
                    {
                        test = getResources().getStringArray(R.array.nodata);
                    }
                }
                if(textPriceRange.equals("500,001 - 750,000")) {
                    if(textRoom.equals("1 Room"))
                    {
                        test = getResources().getStringArray(R.array.nodata);
                    }
                    else if (textRoom.equals("2 Room"))
                    {
                        test = getResources().getStringArray(R.array.nodata);
                    }
                    else if (textRoom.equals("3 Room"))
                    {
                        test = getResources().getStringArray(R.array.nodata);
                    }
                    else if (textRoom.equals("4 Room"))
                    {
                        test = getResources().getStringArray(R.array.bp4room500);
                    }
                    else if (textRoom.equals("5 Room"))
                    {
                        test = getResources().getStringArray(R.array.bp5room500);
                    }
                }

            }
            else if(textLocation.equals("Choa Chu Kang")) {
                if(textPriceRange.equals("50,001 - 200,000")) {
                    if(textRoom.equals("1 Room"))
                    {
                        test = getResources().getStringArray(R.array.cck1room50);
                    }
                    else if (textRoom.equals("2 Room"))
                    {
                        test = getResources().getStringArray(R.array.cck2room50);
                    }
                    else if (textRoom.equals("3 Room"))
                    {
                        test = getResources().getStringArray(R.array.nodata);
                    }
                    else if (textRoom.equals("4 Room"))
                    {
                        test = getResources().getStringArray(R.array.nodata);
                    }
                    else if (textRoom.equals("5 Room"))
                    {
                        test = getResources().getStringArray(R.array.nodata);
                    }
                }
                if(textPriceRange.equals("200,001 - 350,000")) {
                    if(textRoom.equals("1 Room"))
                    {
                        test = getResources().getStringArray(R.array.nodata);
                    }
                    else if (textRoom.equals("2 Room"))
                    {
                        test = getResources().getStringArray(R.array.cck2room200);
                    }
                    else if (textRoom.equals("3 Room"))
                    {
                        test = getResources().getStringArray(R.array.cck3room200);
                    }
                    else if (textRoom.equals("4 Room"))
                    {
                        test = getResources().getStringArray(R.array.nodata);
                    }
                    else if (textRoom.equals("5 Room"))
                    {
                        test = getResources().getStringArray(R.array.nodata);
                    }
                }
                if(textPriceRange.equals("350,001 - 500,000")) {
                    if(textRoom.equals("1 Room"))
                    {
                        test = getResources().getStringArray(R.array.nodata);
                    }
                    else if (textRoom.equals("2 Room"))
                    {
                        test = getResources().getStringArray(R.array.nodata);
                    }
                    else if (textRoom.equals("3 Room"))
                    {
                        test = getResources().getStringArray(R.array.cck3room350);
                    }
                    else if (textRoom.equals("4 Room"))
                    {
                        test = getResources().getStringArray(R.array.cck4room350);
                    }
                    else if (textRoom.equals("5 Room"))
                    {
                        test = getResources().getStringArray(R.array.nodata);
                    }
                }
                if(textPriceRange.equals("500,001 - 750,000")) {
                    if(textRoom.equals("1 Room"))
                    {
                        test = getResources().getStringArray(R.array.nodata);
                    }
                    else if (textRoom.equals("2 Room"))
                    {
                        test = getResources().getStringArray(R.array.nodata);
                    }
                    else if (textRoom.equals("3 Room"))
                    {
                        test = getResources().getStringArray(R.array.nodata);
                    }
                    else if (textRoom.equals("4 Room"))
                    {
                        test = getResources().getStringArray(R.array.cck4room500);
                    }
                    else if (textRoom.equals("5 Room"))
                    {
                        test = getResources().getStringArray(R.array.cck5room500);
                    }
                }

            }
            else{
                test = getResources().getStringArray(R.array.nodata);
            }
            lv = (ListView)findViewById(R.id.listView);
            adapter = new ArrayAdapter<String>(this, android.R.layout.simple_list_item_1, test);
            lv.setAdapter(adapter);
            adapter.notifyDataSetChanged();
            lv.setOnItemClickListener(onListClick);

        }
    }

    private AdapterView.OnItemClickListener onListClick = new AdapterView.OnItemClickListener() {
        public void onItemClick(AdapterView<?> parent, View view, int position, long id) {

            int pos = position;
            String tmp = adapter.getItem(pos);
            Intent i = new Intent(ViewFlatQueryUI.this, ViewFlatResultUI.class);
            i.putExtra("textLocation", textLocation);
            i.putExtra("textflatdetails", tmp);
            i.putExtra("mainMenu", mainMenu);
            startActivity(i);
        }
    };
}
