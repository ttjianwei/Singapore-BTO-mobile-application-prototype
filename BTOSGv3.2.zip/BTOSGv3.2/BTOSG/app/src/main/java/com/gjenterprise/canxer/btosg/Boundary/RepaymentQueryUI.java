package com.gjenterprise.canxer.btosg.Boundary;
import android.content.DialogInterface;
import android.os.Bundle;
import android.support.v7.app.AlertDialog;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.Toolbar;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.content.Intent;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Spinner;
import android.widget.TextView;

import com.gjenterprise.canxer.btosg.Control.MainMenu;
import com.gjenterprise.canxer.btosg.Control.RepaymentMgr;
import com.gjenterprise.canxer.btosg.R;

/**
 * Created by Canxer on 8/10/2016.
 */
public class RepaymentQueryUI extends AppCompatActivity implements View.OnClickListener {

    MainMenu mainMenu;
    EditText loanInput;
    Button bt_calculate;
    TextView tv_result, t;
    public Spinner spinnerDRYearOfLoan;
    public Spinner spinnerDRTypeOfLoan;


    public boolean onCreateOptionsMenu(Menu menu) {

        getMenuInflater().inflate(R.menu.menu, menu);
        return super.onCreateOptionsMenu(menu);
    }
    @Override
    public boolean onOptionsItemSelected(MenuItem item){
        int id = item.getItemId();
        if (id == R.id.Home) {
            Intent intent = new Intent(this,MainMenuUI.class);
            this.startActivity(intent);
            return true;
        }

        if (id == R.id.about) {
            Intent intent = new Intent(this,MenuAboutUs.class);
            this.startActivity(intent);
            return true;
        }
        if (id == R.id.contact) {
            Intent intent = new Intent(this,MenuContactUs.class);
            this.startActivity(intent);
            return true;

        }
        return super.onOptionsItemSelected(item);

    }
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_repaymentquery);

        Toolbar my_toolbar = (Toolbar) findViewById(R.id.my_toolbar);
        setSupportActionBar(my_toolbar);
        getSupportActionBar().setTitle(R.string.my_tb_title);
        getSupportActionBar().setSubtitle("Repayment Query");

        loanInput = (EditText) findViewById(R.id.txtLoanAmount);
        bt_calculate = (Button) findViewById(R.id.bt_calculate);
        bt_calculate.setOnClickListener(this);
        tv_result = (TextView) findViewById(R.id.tv_result);
        t = (TextView) findViewById(R.id.t);
        spinnerDRYearOfLoan=(Spinner)findViewById(R.id.spinnerDRYearOfLoan);
        spinnerDRTypeOfLoan=(Spinner)findViewById(R.id.spinnerTypeOfLoan);
    }
    @Override
    public void onClick(View v) {
        // Do something in response to button
        try {
            String amount = loanInput.getText().toString(); //get amount'
            if(Integer.parseInt(amount) < 10000){
                AlertDialog alertDialog = new AlertDialog.Builder(this).create();
                alertDialog.setTitle("Error");
                alertDialog.setMessage("Amount cannot be less than $10,000!");
                alertDialog.setButton(AlertDialog.BUTTON_NEUTRAL, "OK",
                        new DialogInterface.OnClickListener() {
                            public void onClick(DialogInterface dialog, int which) {
                                dialog.dismiss();
                            }
                        });
                alertDialog.show();
                return;
            }
            if(Integer.parseInt(amount) > 1000000){
                AlertDialog alertDialog = new AlertDialog.Builder(this).create();
                alertDialog.setTitle("Error");
                alertDialog.setMessage("Amount cannot be more than $1,000,000!");
                alertDialog.setButton(AlertDialog.BUTTON_NEUTRAL, "OK",
                        new DialogInterface.OnClickListener() {
                            public void onClick(DialogInterface dialog, int which) {
                                dialog.dismiss();
                            }
                        });
                alertDialog.show();
                return;
            }
            String type = spinnerDRTypeOfLoan.getSelectedItem().toString();
            String year = spinnerDRYearOfLoan.getSelectedItem().toString();//get year
            Double result = RepaymentMgr.makeCalculation(amount,year, type); //calculate function
            int newResult = (int)(Math.round(result));
            tv_result.setText("$ " + newResult); //display
        }
        catch(Exception e){
            AlertDialog alertDialog = new AlertDialog.Builder(this).create();
            alertDialog.setTitle("Error");
            alertDialog.setMessage("Amount cannot be empty!");
            alertDialog.setButton(AlertDialog.BUTTON_NEUTRAL, "OK",
                    new DialogInterface.OnClickListener() {
                        public void onClick(DialogInterface dialog, int which) {
                            dialog.dismiss();
                        }
                    });
            alertDialog.show();
        }

    }

    public void viewGrant(View view) {
        // Do something in response to button
        Intent intent = new Intent(this,GrantQueryUI.class);
        intent.putExtra("mainMenu", mainMenu);
        startActivity(intent);
    }
    public void viewRepayment(View view) {
        // Do something in response to button
        Intent intent = new Intent(this,RepaymentQueryUI.class);
        intent.putExtra("mainMenu", mainMenu);
        startActivity(intent);
    }
    public void viewFlats(View view) {
        // Do something in response to button
        Intent intent = new Intent(this,ViewFlatQueryUI.class);
        intent.putExtra("mainMenu", mainMenu);
        startActivity(intent);
    }
}