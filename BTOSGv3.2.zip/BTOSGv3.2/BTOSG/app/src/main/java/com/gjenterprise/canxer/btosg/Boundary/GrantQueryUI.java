package com.gjenterprise.canxer.btosg.Boundary;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.Toolbar;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.content.Intent;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Spinner;

import com.gjenterprise.canxer.btosg.Control.GrantMgr;
import com.gjenterprise.canxer.btosg.Control.MainMenu;
import com.gjenterprise.canxer.btosg.R;


import static com.gjenterprise.canxer.btosg.R.id.dropDownBoxIncome;


/**
 * Created by Canxer on 8/10/2016.
 */

public class GrantQueryUI extends AppCompatActivity implements AdapterView.OnItemSelectedListener{
    MainMenu mainMenu;
    Spinner spinnerApplicant;
    Spinner spinnerAvgIncome;
    Spinner spinnerSaleLaunch;

    public boolean onCreateOptionsMenu(Menu menu) {

        getMenuInflater().inflate(R.menu.menu, menu);
        return super.onCreateOptionsMenu(menu);
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item){
        int id = item.getItemId();
        if (id == R.id.Home) {
            Intent intent = new Intent(this,MainMenuUI.class);
            this.startActivity(intent);
            return true;
        }

        if (id == R.id.about) {
            Intent intent = new Intent(this,MenuAboutUs.class);
            this.startActivity(intent);
            return true;
        }
        if (id == R.id.contact) {
            Intent intent = new Intent(this,MenuContactUs.class);
            this.startActivity(intent);
            return true;

        }
        return super.onOptionsItemSelected(item);

    }
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_grantquery);
        Toolbar my_toolbar = (Toolbar) findViewById(R.id.my_toolbar);
        setSupportActionBar(my_toolbar);
        getSupportActionBar().setTitle(R.string.my_tb_title);
        getSupportActionBar().setSubtitle("Grant Query");

        spinnerApplicant=(Spinner)findViewById(R.id.dropDownBoxApplicant);
        spinnerAvgIncome=(Spinner)findViewById(dropDownBoxIncome);
        spinnerSaleLaunch=(Spinner)findViewById(R.id.dropDownBoxSales);


        /*Dynamic population of spinner income*/
        spinnerApplicant.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            private String[] arraySpinner;

            @Override
            public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
                if(spinnerApplicant.getSelectedItem().equals("First-Timer Couple")||spinnerApplicant.getSelectedItem().equals("Joint Singles Scheme")||spinnerApplicant.getSelectedItem().equals("Orphans Scheme"))
                {
                    this.arraySpinner=new String[]{"Up to $1,500","$1,501 to $2,000","$2,001 to $2,500",
                            "$2,501 to $3,000","$3,001 to $3,500","$3,501 to $4,000",
                            "$4,001 to $4,500","$4,501 to $5,000","$5,001 to $5,500",
                            "$5,501 to $6,000","$6,001 to $6,500","$6,501 to $7,000",
                            "$7,001 to $7,500","$7,501 to $8,000","$8,001 to $8,500" };
                }
                else
                {
                    this.arraySpinner=new String[]{"Up to $750","$751 to $1,000","$1,001 to $1,250",
                            "$1,251 to $1,500","$1,501 to $1,750","$1,751 to $2,000",
                            "$2,001 to $2,250","$2,251 to $2,500","$2,501 to $2,750",
                            "$2,751 to $3,000","$3,001 to $3,250","$3,251 to $3,500",
                            "$3,501 to $3,750","$3,751 to $4,000","$4,001 to $4,250" };
                }

                ArrayAdapter<String> adapter=new ArrayAdapter<String>(GrantQueryUI.this,android.R.layout.simple_spinner_item,arraySpinner);
                spinnerAvgIncome.setAdapter(adapter);
            }

            @Override
            public void onNothingSelected(AdapterView<?> parent) {
            }
        });
    }



    public void viewResult(View view){
        // Do something in response to button
        spinnerApplicant.setOnItemSelectedListener(this);
        spinnerAvgIncome.setOnItemSelectedListener(this);
        spinnerSaleLaunch.setOnItemSelectedListener(this);

        String textApplicant=spinnerApplicant.getSelectedItem().toString();
        String textAvgIncome=spinnerAvgIncome.getSelectedItem().toString();
        String textSaleLaunch=spinnerSaleLaunch.getSelectedItem().toString();

        GrantMgr grantmgr=new GrantMgr();
        grantmgr.GetGrantDetails(textApplicant,textAvgIncome,textSaleLaunch,this);
    }

    public void viewGrant(View view) {
        // Do something in response to button
        Intent intent = new Intent(this,GrantQueryUI.class);
        intent.putExtra("mainMenu", mainMenu);
        startActivity(intent);
    }
    public void viewRepayment(View view) {
        // Do something in response to button
        Intent intent = new Intent(this,RepaymentQueryUI.class);
        intent.putExtra("mainMenu", mainMenu);
        startActivity(intent);
    }
    public void viewFlats(View view) {
        // Do something in response to button
        Intent intent = new Intent(this,ViewFlatQueryUI.class);
        intent.putExtra("mainMenu", mainMenu);
        startActivity(intent);
    }

    @Override
    public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
    }

    @Override
    public void onNothingSelected(AdapterView<?> parent) {

    }
}
